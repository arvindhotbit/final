export const environment = {
  production: true,
  apiUrl: 'http://192.168.1.208:8900/api'
};
