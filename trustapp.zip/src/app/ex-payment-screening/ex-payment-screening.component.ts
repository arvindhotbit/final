import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ex-payment-screening',
  templateUrl: './ex-payment-screening.component.html',
  styleUrls: ['./ex-payment-screening.component.css']
})
export class ExPaymentScreeningComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
