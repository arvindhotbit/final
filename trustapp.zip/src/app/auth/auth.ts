


export interface Auth {
    id : string,
    role : string,
    userid: string,
    cn: string,
    sn: string,
    email: string,
    password: string,
    empNo: string,
    department: string,
    roles: string
  
}


