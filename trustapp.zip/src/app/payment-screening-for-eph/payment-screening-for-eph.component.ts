import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-screening-for-eph',
  templateUrl: './payment-screening-for-eph.component.html',
  styleUrls: ['./payment-screening-for-eph.component.css']
})
export class PaymentScreeningForEPHComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
