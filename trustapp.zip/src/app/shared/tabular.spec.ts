import { Tabular } from './tabular';

describe('Tabular', () => {
  it('should create an instance', () => {
    expect(new Tabular()).toBeTruthy();
  });
});
